﻿using System;
class Program
{
    static void Main()
    {
        Console.WriteLine("introduzca un numero entero");
        int a;
        a = int.Parse(Console.ReadLine());
        int j = 1;
        for(int i=0; i<=a; i++)
        {
            Console.WriteLine(j);
            j = j+2;
        }
    }
}